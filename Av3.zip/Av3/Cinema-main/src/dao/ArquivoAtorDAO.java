package dao;

import model.Ator;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArquivoAtorDAO {

    private static final String FILE_PATH = "data/atores.txt";


    public void salvarAtor(Ator ator) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            bw.write(String.format("%s;%s;%s;%d%n",
                    ator.getCpf(),
                    ator.getNome(),
                    ator.getEmail(),
                    ator.getRegistro()));
        } catch (IOException e) {
            System.out.println("Erro ao salvar ator: " + e.getMessage());
        }
    }


    public List<Ator> listarAtores() {
        List<Ator> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                lista.add(new Ator(partes[0], partes[1], partes[2], Integer.parseInt(partes[3])));
            }
        } catch (IOException e) {
            System.out.println("Erro ao listar atores: " + e.getMessage());
        }
        return lista;
    }

    public void atualizarAtor(Ator atorAtualizado) {
        File arquivoOriginal = new File(FILE_PATH);
        File arquivoTemp = new File(FILE_PATH + ".tmp");
        boolean atualizado = false;

        try (BufferedReader leitor = new BufferedReader(new FileReader(arquivoOriginal));
             BufferedWriter escritor = new BufferedWriter(new FileWriter(arquivoTemp))) {

            String linha;
            while ((linha = leitor.readLine()) != null) {
                String[] dados = linha.split(";");
                if (dados.length >= 4) {
                    String registroAtual = dados[3];


                    if (Integer.toString(atorAtualizado.getRegistro()).equals(registroAtual)) {

                        String novaLinha = String.format("%s;%s;%s;%d",
                                atorAtualizado.getCpf(),
                                atorAtualizado.getNome(),
                                atorAtualizado.getEmail(),
                                atorAtualizado.getRegistro());
                        escritor.write(novaLinha);
                        escritor.newLine();
                        atualizado = true;
                    } else {

                        escritor.write(linha);
                        escritor.newLine();
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao atualizar o ator: " + e.getMessage());
        }


        if (atualizado) {
            if (arquivoOriginal.delete() && arquivoTemp.renameTo(arquivoOriginal)) {
                System.out.println("Ator atualizado com sucesso.");
            } else {
                System.out.println("Erro ao substituir o arquivo original.");
            }
        } else {
            System.out.println("Ator não encontrado.");
            arquivoTemp.delete();
        }
    }

    public Ator buscarAtorPorCpf(String cpf) {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes[0].equals(cpf)) {
                    return new Ator(partes[0], partes[1], partes[2], Integer.parseInt(partes[3]));
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao buscar ator por CPF: " + e.getMessage());
        }
        return null;
    }
    public Ator buscarAtorPorId(int id) {
        File arquivo = new File(FILE_PATH);

        try (BufferedReader reader = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length >= 4) {
                    int registro = Integer.parseInt(partes[3]);
                    if (registro == id) {
                        String nome = partes[1];
                        String email = partes[2];
                        String cpf = partes[0];
                        return new Ator(cpf, nome, email, registro);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }


        return null;
    }
}

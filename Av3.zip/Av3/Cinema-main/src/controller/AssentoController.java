package controller;

import model.Assento;
import model.TipoAssento;
import dao.AssentoDAO;
import dao.TipoAssentoDAO;

import java.util.List;

public class AssentoController {

    private final AssentoDAO assentoDAO = new AssentoDAO();
    private final TipoAssentoDAO tipoAssentoDAO = new TipoAssentoDAO();


    public void cadastrarAssento(Assento assento) {
        assentoDAO.cadastrarAssento(assento);
    }
    public Assento buscarAssentoPorDescricao(String descricao) {
        return assentoDAO.listarAssentos().stream()
                .filter(assent -> assent.getTipoAssento().getDescricao().equalsIgnoreCase(descricao))
                .findFirst()
                .orElse(null);
    }


    public List<Assento> listarAssentos() {
        return assentoDAO.listarAssentos();
    }
}

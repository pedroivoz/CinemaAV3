package view;

import controller.AssentoController;
import controller.SalaAssentoController;
import controller.SalaController;
import controller.TipoAssentoController;
import dao.SalaAssentoDAO;
import dao.SalaDAO;
import model.Assento;
import model.Sala;
import model.TipoAssento;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SalaAssentoView {
     SalaController salaController = new SalaController();
     TipoAssentoController tipoAssentoController = new TipoAssentoController();
     AssentoController assento= new AssentoController();
    SalaAssentoController salaAssentoController = new SalaAssentoController();

    private Scanner scanner = new Scanner(System.in);

    public void exibirMenuSalaAssento() {
        while (true) {
            System.out.println("========== GERENCIAR SALAS E ASSENTOS ==========");
            System.out.println("1 - Cadastrar Sala com Assentos");
            System.out.println("2 - Listar Salas");
            System.out.println("3 - Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarSalaComAssentos();
                    break;
                case 2:
                    listarSalas();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
    }
    public void cadastrarSalaComAssentos() {
        System.out.println("=== Cadastro de Sala com Assentos ===");


        System.out.print("Digite a descrição da sala: ");
        String descricao = scanner.nextLine();

        System.out.print("Digite a capacidade da sala (número total de assentos): ");
        int capacidade = scanner.nextInt();
        scanner.nextLine();


        List<TipoAssento> tiposAssento = selecionarTiposDeAssento();
        if (tiposAssento.isEmpty()) {
            System.out.println("Nenhum tipo de assento selecionado. Cadastro cancelado.");
            return;
        }


        Sala novaSala = criarSala(descricao, capacidade, tiposAssento);


        salaAssentoController.salvarSalaComAssentos(novaSala);
        System.out.println("Sala cadastrada com sucesso!");
    }

    private List<TipoAssento> selecionarTiposDeAssento() {
        System.out.println("=== Seleção de Tipos de Assento ===");
        List<TipoAssento> todosTipos = tipoAssentoController.listarTipoAssento();
        List<TipoAssento> tiposSelecionados = new ArrayList<>();

        if (todosTipos.isEmpty()) {
            System.out.println("Não há tipos de assento cadastrados. Adicione-os antes de criar a sala.");
            return tiposSelecionados;
        }

        for (TipoAssento tipo : todosTipos) {
            System.out.printf("Deseja incluir o tipo '%s' (Sim/Não)? ", tipo.getDescricao());
            String resposta = scanner.nextLine().trim().toLowerCase();

            if (resposta.equals("sim")) {
                tiposSelecionados.add(tipo);
            }
        }

        return tiposSelecionados;
    }

    private Sala criarSala(String descricao, int capacidade, List<TipoAssento> tiposAssento) {
        System.out.println("=== Criando sala e associando assentos ===");
        List<Assento> assentos = new ArrayList<>();

        int idAssento = 1;
        for (TipoAssento tipo : tiposAssento) {
            for (int i = 0; i < capacidade / tiposAssento.size(); i++) {
                assentos.add(new Assento(idAssento++, tipo));
            }
        }


        List<Sala> salasExistentes = salaController.listarSalas();
        int novoIdSala = salasExistentes.isEmpty() ? 1 : salasExistentes.get(salasExistentes.size() - 1).getIdSala() + 1;

        return new Sala(novoIdSala, descricao, capacidade, assentos);
    }


    private void listarSalas() {
        SalaDAO salaDAO = new SalaDAO();
        SalaAssentoDAO salaAssentoDAO = new SalaAssentoDAO();

        List<Sala> salas = salaDAO.listarSalas();
        if (salas.isEmpty()) {
            System.out.println("Nenhuma sala cadastrada.");
        } else {
            System.out.println("========== SALAS CADASTRADAS ==========");
            for (Sala sala : salas) {
                System.out.println("ID: " + sala.getIdSala() + ", Descrição: " + sala.getDescricao() +
                        ", Capacidade: " + sala.getCapacidadeSala());

                List<Assento> assentos = salaAssentoDAO.listarAssentosPorSala(sala.getIdSala());
                if (assentos.isEmpty()) {
                    System.out.println("  Nenhum assento cadastrado.");
                } else {
                    System.out.println("  Assentos:");
                    for (Assento assento : assentos) {
                        System.out.println("    - Número: " + assento.getNumero() + ", Tipo: " + assento.getTipoAssento().getDescricao());
                    }
                }

            }
        }
    }
}


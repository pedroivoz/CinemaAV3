import view.MenuPrincipal;

public class Main {
    public static void main(String[] args) {

        System.out.println("Seja bem vindo ao Cinema UNIFOR: ");
        System.out.println("Por favor digite o número correspodente a sua opção: ");
        MenuPrincipal menu = new MenuPrincipal();
        menu.exibirMenuPrincipal();


    }
}
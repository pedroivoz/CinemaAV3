package view;

import controller.SessaoController;
import controller.FilmeController;
import controller.SalaController;
import controller.FuncionarioController;
import model.Sessao;
import model.Filme;
import model.Sala;
import model.Funcionario;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

public class SessaoView {

    private final SessaoController sessaoController = new SessaoController();
    private final FilmeController filmeController = new FilmeController();
    private final SalaController salaController = new SalaController();
    private final FuncionarioController funcionarioController = new FuncionarioController();
    private final Scanner scanner = new Scanner(System.in);

    public void exibirMenuSessao() {
        int opcao;
        do {
            System.out.println("========== GERENCIAR SESSÕES ==========");
            System.out.println("1 - Cadastrar Sessão");
            System.out.println("2 - Listar Sessões");
            System.out.println("3 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarSessao();
                case 2 -> listarSessoes();
                case 3 -> System.out.println("Voltando ao menu anterior...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 3);
    }

    private void cadastrarSessao() {
        System.out.print("Digite a data e hora da sessão (yyyy-MM-dd HH:mm:ss): ");
        String dataHoraSessaoStr = scanner.nextLine();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date dataHoraSessao = null;
        try {
            dataHoraSessao = format.parse(dataHoraSessaoStr);
        } catch (ParseException e) {
            System.out.println("Formato de data inválido.");
            return;
        }


        List<Filme> filmes = filmeController.listarFilmes();
        if (filmes.isEmpty()) {
            System.out.println("Nenhum filme cadastrado.");
            return;
        }

        System.out.println("Escolha o ID do Filme:");
        for (Filme filme : filmes) {
            System.out.println(filme.getIdFilme() + " - " + filme.getTitulo());
        }
        int filmeId = scanner.nextInt();
        Filme filme = filmeController.buscarFilmePorId(filmeId);
        if (filme == null) {
            System.out.println("Filme não encontrado.");
            return;
        }


        List<Sala> salas = salaController.listarSalas();
        if (salas.isEmpty()) {
            System.out.println("Nenhuma sala cadastrada.");
            return;
        }

        System.out.println("Escolha o ID da Sala:");
        for (Sala sala : salas) {
            System.out.println(sala.getIdSala() + " - " + sala.getDescricao());
        }
        int salaId = scanner.nextInt();
        Sala sala = salaController.buscarSalaPorId(salaId);
        if (sala == null) {
            System.out.println("Sala não encontrada.");
            return;
        }


        List<Funcionario> funcionarios = funcionarioController.listarFuncionarios();
        if (funcionarios.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
            return;
        }

        System.out.println("Escolha o ID do Funcionário:");
        for (Funcionario funcionario : funcionarios) {
            System.out.println(funcionario.getMatricula() + " - " + funcionario.getNome());
        }
        int funcionarioMatricula = scanner.nextInt();
        Funcionario funcionario = funcionarioController.consultarFuncionarioPorMatricula(funcionarioMatricula);
        if (funcionario == null) {
            System.out.println("Funcionário não encontrado.");
            return;
        }


        scanner.nextLine();
        System.out.print("Digite o status da sessão (Ativa/Inativa): ");
        String status = scanner.nextLine();


        Sessao sessao = new Sessao(0, dataHoraSessao, filme, sala, funcionario, status);
        sessaoController.cadastrarSessao(sessao);

        System.out.println("Sessão cadastrada com sucesso!");
    }

    private void listarSessoes() {
        List<Sessao> sessoes = sessaoController.listarSessoes();
        if (sessoes.isEmpty()) {
            System.out.println("Nenhuma sessão cadastrada.");
        } else {
            System.out.println("========== SESSÕES CADASTRADAS ==========");
            for (Sessao sessao : sessoes) {
                System.out.println("ID: " + sessao.getIdSessao() +
                        ", Data: " + sessao.getDataHoraSessao() +
                        ", Filme: " + sessao.getFilme().getTitulo() +
                        ", Sala: " + sessao.getSala().getDescricao() +
                        ", Funcionário: " + sessao.getFuncionario().getNome() +
                        ", Status: " + sessao.getStatus());
            }

        }
    }
}

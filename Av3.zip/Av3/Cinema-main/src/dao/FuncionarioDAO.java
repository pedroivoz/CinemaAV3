package dao;

import model.Funcionario;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FuncionarioDAO {

    private final String caminhoArquivo = "data/funcionarios.txt";


    public void salvarFuncionario(Funcionario funcionario) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(caminhoArquivo, true))) {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String dataTrabalho = sdf.format(funcionario.getHorarioTrabalho());


            writer.write(funcionario.getCpf() + ";" + funcionario.getNome() + ";" + funcionario.getEmail() + ";" + funcionario.getMatricula() + ";" + dataTrabalho);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Erro ao salvar funcionário: " + e.getMessage());
        }
    }


    public List<Funcionario> listarFuncionarios() {
        List<Funcionario> funcionarios = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(";");


                String cpf = dados[0];
                String nome = dados[1];
                String email = dados[2];
                int matricula = Integer.parseInt(dados[3]);
                Date horarioTrabalho = sdf.parse(dados[4]);

                Funcionario funcionario = new Funcionario(cpf, nome, email, matricula, horarioTrabalho);
                funcionarios.add(funcionario);
            }
        } catch (IOException | java.text.ParseException e) {
            System.out.println("Erro ao listar funcionários: " + e.getMessage());
        }
        return funcionarios;
    }


    public Funcionario consultarFuncionarioPorMatricula(int matricula) {
        List<Funcionario> funcionarios = listarFuncionarios();
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getMatricula() == matricula) {
                return funcionario;
            }
        }
        return null;
    }
}

package controller;

import dao.SalaDAO;
import dao.AssentoDAO;
import model.Sala;
import model.Assento;
import model.TipoAssento;

import java.util.ArrayList;
import java.util.List;

public class SalaController {
    private SalaDAO salaDAO = new SalaDAO();
    private AssentoDAO assentoDAO = new AssentoDAO();


    public void cadastrarSala(String descricao, int capacidade, List<TipoAssento> tiposAssento) {
        List<Assento> assentos = new ArrayList<>();


        for (TipoAssento tipo : tiposAssento) {
            for (int i = 1; i <= capacidade; i++) {
                int idAssento = i;
                Assento assento = new Assento(idAssento, tipo);
                assentos.add(assento);
            }
        }


        List<Sala> salas = salaDAO.listarSalas();
        int novoIdSala = salas.isEmpty() ? 1 : salas.get(salas.size() - 1).getIdSala() + 1;


        Sala novaSala = new Sala(novoIdSala, descricao, capacidade, assentos);
        salaDAO.salvarSala(novaSala);
    }

    public List<Sala> listarSalas() {
        return salaDAO.listarSalas();
    }
    public Sala buscarSalaPorId(int idSala) {
        List<Sala> salas = salaDAO.listarSalas();
        return salas.stream()
                .filter(sala -> sala.getIdSala() == idSala)
                .findFirst()
                .orElse(null);
    }
}

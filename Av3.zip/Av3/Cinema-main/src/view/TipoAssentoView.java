package view;

import model.TipoAssento;
import controller.TipoAssentoController;

import java.util.List;
import java.util.Scanner;

public class TipoAssentoView {

    private final Scanner scanner = new Scanner(System.in);
    private final TipoAssentoController controller = new TipoAssentoController();


    public void exibirMenuTipoAssento() {
        int selecao;

        do {
            System.out.println("========== GERENCIAR TIPO DE ASSENTOS ==========");
            System.out.println("1 - Gerenciar Assentos");
            System.out.println("2 - Cadastrar Tipo de Assento");
            System.out.println("3 - Listar Tipos de Assento");
            System.out.println("4 - Voltar");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> new AssentoView().exibirMenuAssento();
                case 2 -> cadastrarTipoAssento();
                case 3 -> listarTiposAssento();
                case 4 -> System.out.println("Voltando ao menu anterior...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 4);
    }

    private void cadastrarTipoAssento() {
        System.out.print("Digite a descrição do Tipo de Assento: ");
        String descricao = scanner.nextLine();

        System.out.print("Digite o status do Tipo de Assento (Ativo/Inativo): ");
        String status = scanner.nextLine();


        TipoAssento tipoAssento = new TipoAssento(0, descricao, status);


        controller.cadastrarTipoAssento(tipoAssento);
    }


    private void listarTiposAssento() {
        List<TipoAssento> tiposAssento = controller.listarTipoAssento();

        if (tiposAssento.isEmpty()) {
            System.out.println("Nenhum tipo de assento cadastrado.");
        } else {
            System.out.println("========== TIPOS DE ASSENTO ==========");
            for (TipoAssento tipoAssento : tiposAssento) {
                System.out.println("ID: " + tipoAssento.getIdTipoAssento() +
                        ", Descrição: " + tipoAssento.getDescricao() +
                        ", Status: " + tipoAssento.getStatus());
            }
        }
    }
}

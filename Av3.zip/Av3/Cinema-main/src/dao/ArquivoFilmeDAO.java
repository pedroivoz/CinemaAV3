package dao;

import model.Filme;
import model.Genero;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArquivoFilmeDAO {

    private static final String CAMINHO_ARQUIVO = "data/filmes.txt";
    private final List<Filme> filmes = new ArrayList<>();
    private int idCounter = 1;



    public Filme buscarFilmePorId(int idFilme) {
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Filme filme = converterLinhaParaFilme(linha);
                if (filme != null && filme.getIdFilme() == idFilme) {
                    return filme;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao buscar filme por ID no arquivo: " + e.getMessage());
        }
        return null;
    }



    public void cadastrarFilme(Filme filme) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, true))) {
            String linha = formatarFilmeParaLinha(filme);
            writer.write(linha);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erro ao salvar o filme: " + e.getMessage());
        }
    }


    public List<Filme> listarFilmes() {
        List<Filme> filmes = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Filme filme = converterLinhaParaFilme(linha);
                if (filme != null) {
                    filmes.add(filme);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler arquivo de filmes: " + e.getMessage());
        }

        return filmes;
    }



    public void editarFilme(Filme filmeEditado) {
        List<Filme> filmes = listarFilmes();
        boolean atualizado = false;

        for (int i = 0; i < filmes.size(); i++) {
            Filme filme = filmes.get(i);
            if (filme.getIdFilme() == filmeEditado.getIdFilme() ||
                    filme.getTitulo().equalsIgnoreCase(filmeEditado.getTitulo())) {
                filmes.set(i, filmeEditado);
                atualizado = true;
                break;
            }
        }

        if (atualizado) {
            salvarFilmesNoArquivo(filmes);
            System.out.println("Filme atualizado com sucesso no arquivo.");
        } else {
            System.out.println("Filme não encontrado para atualização.");
        }
    }

    public void atualizarFilmes(List<Filme> filmes) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO))) {
            for (Filme filme : filmes) {
                writer.write(String.format("%d;%s;%d;%s;%s\n",
                        filme.getIdFilme(),
                        filme.getTitulo(),
                        filme.getClassificacao(),
                        filme.getGenero().getDescricao(),
                        filme.getStatus()));
            }
        } catch (IOException e) {
            System.err.println("Erro ao atualizar arquivo de filmes: " + e.getMessage());
        }
    }



    private void salvarFilmesNoArquivo(List<Filme> filmes) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, false))) {
            for (Filme filme : filmes) {
                String linha = formatarFilmeParaLinha(filme);
                writer.write(linha);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar os filmes: " + e.getMessage());
        }
    }

    private String formatarFilmeParaLinha(Filme filme) {
        return filme.getIdFilme() + ";" +
                filme.getTitulo() + ";" +
                filme.getClassificacao() + ";" +
                filme.getGenero().getId() + "," + filme.getGenero().getDescricao() + "," + filme.getGenero().getStatus() + ";" +
                filme.getStatus();
    }

    private Filme converterLinhaParaFilme(String linha) {
        try {
            String[] partes = linha.split(";");
            int id = Integer.parseInt(partes[0]);
            String titulo = partes[1];
            int classificacao = Integer.parseInt(partes[2]);

            String[] generoPartes = partes[3].split(",");
            int generoId = Integer.parseInt(generoPartes[0]);
            String descricaoGenero = generoPartes[1];
            String statusGenero = generoPartes[2];

            String status = partes[4];

            Genero genero = new Genero(0, descricaoGenero, statusGenero);
            return new Filme(id, classificacao, titulo, genero, status);
        } catch (Exception e) {
            System.err.println("Erro ao converter linha para filme: " + e.getMessage());
            return null;
        }

    }
    public int buscarMaiorIdFilme() {
        int maiorId = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                int idAtual = Integer.parseInt(dados[0]);
                if (idAtual > maiorId) {
                    maiorId = idAtual;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao buscar maior ID de filme: " + e.getMessage());
        }
        return maiorId;
    }



}


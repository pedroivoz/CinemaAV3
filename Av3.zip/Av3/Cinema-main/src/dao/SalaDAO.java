package dao;

import model.Sala;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SalaDAO {
    private static final String ARQUIVO_SALAS = "data/salas.txt";

    public List<Sala> listarSalas() {
        List<Sala> salas = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_SALAS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length == 3) {
                    int id = Integer.parseInt(partes[0].trim());
                    String descricao = partes[1].trim();
                    int capacidade = Integer.parseInt(partes[2].trim());
                    salas.add(new Sala(id, descricao, capacidade));
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao carregar as salas: " + e.getMessage());
        }
        return salas;
    }

    public void salvarSala(Sala sala) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARQUIVO_SALAS, true))) {
            writer.write(sala.getIdSala() + ";" + sala.getDescricao() + ";" + sala.getCapacidadeSala());
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erro ao salvar a sala: " + e.getMessage());
        }
    }
    public Sala buscarSalaPorId(int idSala) {
        List<Sala> salas = listarSalas();
        for (Sala sala : salas) {
            if (sala.getIdSala() == idSala) {
                return sala;
            }
        }
        return null;
    }


}

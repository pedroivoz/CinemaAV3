package dao;

import controller.TipoAssentoController;
import model.SalaAssento;
import model.Sala;
import model.Assento;
import model.TipoAssento;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SalaAssentoDAO {

    private static final String CAMINHO_ARQUIVO = "data/sala_assentos.txt";
    TipoAssentoController tipoAssentoController = new TipoAssentoController();


    public void cadastrarSalaAssento(SalaAssento salaAssento) {
        int novoIdSalaAssento = obterProximoIdSalaAssento();
        salaAssento.setIdSalaAssento(novoIdSalaAssento);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, true))) {
            String linha = formatarSalaAssentoParaLinha(salaAssento);
            writer.write(linha);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erro ao salvar sala-assento: " + e.getMessage());
        }
    }

    public void cadastrarSalaComAssentos(Sala sala) {
        for (Assento assento : sala.getAssentos()) {
            SalaAssento salaAssento = new SalaAssento(0, assento, sala);
            cadastrarSalaAssento(salaAssento);
        }
    }


    public List<SalaAssento> listarSalaAssentos() {
        List<SalaAssento> salaAssentos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                SalaAssento salaAssento = converterLinhaParaSalaAssento(linha);
                if (salaAssento != null) {
                    salaAssentos.add(salaAssento);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler arquivo de sala-assentos: " + e.getMessage());
        }
        return salaAssentos;
    }

    public List<Assento> listarAssentosPorSala(int idSala) {
        List<Assento> assentos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(";");
                if (partes.length == 4) {
                    int idSalaArquivo = Integer.parseInt(partes[1].trim());
                    if (idSalaArquivo == idSala) {
                        int numeroAssento = Integer.parseInt(partes[2].trim());
                        String descricaoTipoAssento = partes[3].trim();

                        TipoAssento tipoAssento = tipoAssentoController.buscarTipoAssentoPorDescricao(descricaoTipoAssento);
                        if (tipoAssento != null) {
                            assentos.add(new Assento(numeroAssento, tipoAssento));
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao carregar os assentos da sala: " + e.getMessage());
        }
        return assentos;
    }


    public SalaAssento buscarSalaAssentoPorId(int idSalaAssento) {
        List<SalaAssento> salaAssentos = listarSalaAssentos();
        for (SalaAssento salaAssento : salaAssentos) {
            if (salaAssento.getIdSalaAssento() == idSalaAssento) {
                return salaAssento;
            }
        }
        return null;
    }



    private String formatarSalaAssentoParaLinha(SalaAssento salaAssento) {
        return salaAssento.getIdSalaAssento() + ";" +
                salaAssento.getSala().getIdSala() + ";" +
                salaAssento.getAssento().getNumero() + ";" +
                salaAssento.getAssento().getTipoAssento().getDescricao();
    }


    private SalaAssento converterLinhaParaSalaAssento(String linha) {
        try {
            String[] partes = linha.split(";");
            if (partes.length < 4) return null;

            int idSalaAssento = Integer.parseInt(partes[0].trim());
            int idSala = Integer.parseInt(partes[1].trim());
            Sala sala = new SalaDAO().buscarSalaPorId(idSala);

            int numeroAssento = Integer.parseInt(partes[2].trim());
            String descricaoTipoAssento = partes[3].trim();

            TipoAssento tipoAssento = tipoAssentoController.buscarTipoAssentoPorDescricao(descricaoTipoAssento);
            if (sala != null && tipoAssento != null) {
                Assento assento = new Assento(numeroAssento, tipoAssento);
                return new SalaAssento(idSalaAssento, assento, sala);
            }
        } catch (Exception e) {
            System.err.println("Erro ao converter linha para sala-assento: " + e.getMessage());
        }
        return null;
    }


    private int obterProximoIdSalaAssento() {
        List<SalaAssento> salaAssentos = listarSalaAssentos();
        return salaAssentos.isEmpty() ? 1 : salaAssentos.get(salaAssentos.size() - 1).getIdSalaAssento() + 1;
    }

}

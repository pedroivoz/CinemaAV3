package view;

import controller.FilmeAtorController;
import java.util.Scanner;

public class MenuFilmeAtorView {

    private final Scanner scanner = new Scanner(System.in);
    private final FilmeAtorController filmeAtorController = new FilmeAtorController();

    public void exibirMenuFilmeAtor() {
        int selecao;
        do {
            System.out.println("\n===== GERENCIAR FILME-ATOR =====");
            System.out.println("1 - Associar Ator a Filme");
            System.out.println("2 - Listar Associações");
            System.out.println("3 - Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> associarAtorAFilme();
                case 2 -> listarAssociacoes();
                case 3 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 3);
    }

    private void associarAtorAFilme() {
        System.out.println("\n===== ASSOCIAÇÃO DE ATOR A FILME =====");

        System.out.print("ID do Ator: ");
        int idAtor = scanner.nextInt();
        scanner.nextLine();

        System.out.print("ID do Filme: ");
        int idFilme = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Personagem: ");
        String personagem = scanner.nextLine();

        System.out.print("É o principal? (true/false): ");
        boolean principal = scanner.nextBoolean();

        filmeAtorController.associarAtorFilme(idAtor, idFilme, personagem, principal);
    }

    private void listarAssociacoes() {
        System.out.println("\n===== LISTAR ASSOCIAÇÕES =====");
        filmeAtorController.listarFilmesAtores().forEach(fa ->
                System.out.printf("ID FilmeAtor: %d | Ator: %s | Filme: %s | Personagem: %s | Principal: %s\n",
                        fa.getIdFilmeAtor(),
                        fa.getAtor().getNome(),
                        fa.getFilme().getTitulo(),
                        fa.getPersonagem(),
                        fa.isPrincipal() ? "Sim" : "Não"));
    }
}

package model;

public class Assento {
    private int numero;
    private TipoAssento tipoAssento;


    public Assento(int numero, TipoAssento tipoAssento) {
        this.numero = numero;
        this.tipoAssento = tipoAssento;
    }


    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public TipoAssento getTipoAssento() {
        return tipoAssento;
    }

    public void setTipoAssento(TipoAssento tipoAssento) {
        this.tipoAssento = tipoAssento;
    }
}


package controller;

import dao.IngressoDAO;
import exceptions.ArquivoNaoEncontradoException;
import model.Ingresso;
import model.Sessao;
import model.SalaAssento;
import view.MenuPrincipal;

import java.util.List;

public class IngressoController {

    private final IngressoDAO ingressoDAO = new IngressoDAO();

    public void cadastrarIngresso(double valorPago, Sessao sessao, SalaAssento salaAssento) {
        try {
            List<Ingresso> ingressos = ingressoDAO.listarIngressos();
            int novoIdIngresso = ingressos.isEmpty() ? 1 : ingressos.get(ingressos.size() - 1).getIdIngresso() + 1;

            Ingresso novoIngresso = new Ingresso(novoIdIngresso, valorPago, sessao, salaAssento);
            ingressoDAO.cadastrarIngresso(novoIngresso);
            System.out.println("Ingresso cadastrado com sucesso!");

        } catch(ArquivoNaoEncontradoException e) {
            System.err.println(e.getMessage());
            System.out.println("Voltando para o menu principal");
            new MenuPrincipal().exibirMenuPrincipal();
        }

    }

    public List<Ingresso> listarIngressos() {
        return ingressoDAO.listarIngressos();
    }


}

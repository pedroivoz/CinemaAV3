package view;

import controller.AtorController;
import controller.FilmeAtorController;
import model.Ator;
import model.FilmeAtor;

import java.util.Scanner;

public class MenuAtores {

    private final Scanner scanner = new Scanner(System.in);
    private final AtorController atorController = new AtorController();
    private final FilmeAtorController filmeAtorController = new FilmeAtorController();

    public void exibirMenuAtores() {
        int selecao;

        do {
            System.out.println("\n===== GERENCIAR ATORES E ASSOCIAÇÃO FILME-ATOR =====");
            System.out.println("1 - Gerenciar Atores");
            System.out.println("2 - Gerenciar Associação Filme-Ator");
            System.out.println("3 - Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> gerenciarAtores();
                case 2 -> exibirMenuFilmeAtor();
                case 3 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 3);
    }

    private void gerenciarAtores() {
        int selecao;

        do {
            System.out.println("\n===== GERENCIAR ATORES =====");
            System.out.println("1 - Cadastrar Ator");
            System.out.println("2 - Editar Ator");
            System.out.println("3 - Listar Atores");
            System.out.println("4 - Voltar ao Menu de Atores");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> cadastrarAtor();
                case 2 -> editarAtor();
                case 3 -> listarAtores();
                case 4 -> System.out.println("Voltando ao Menu de Atores...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 4);
    }

    private void cadastrarAtor() {
        System.out.println("\n===== CADASTRAR ATOR =====");
        System.out.print("Nome do Ator: ");
        String nome = scanner.nextLine();

        System.out.print("CPF do Ator: ");
        String cpf = scanner.nextLine();

        System.out.print("Email do Ator: ");
        String email = scanner.nextLine();

        System.out.print("Registro do Ator: ");
        int registro = scanner.nextInt();
        scanner.nextLine();

        atorController.cadastrarAtor(cpf, nome, email, registro);
        System.out.println("Ator cadastrado com sucesso!");
    }

    private void editarAtor() {
        System.out.println("\n===== EDITAR ATOR =====");
        System.out.print("Informe o CPF do Ator a ser editado: ");
        String cpf = scanner.nextLine();

        Ator ator = atorController.buscarAtorPorCpf(cpf);
        if (ator != null) {
            System.out.print("Novo Nome: ");
            ator.setNome(scanner.nextLine());

            System.out.print("Novo Email: ");
            ator.setEmail(scanner.nextLine());

            atorController.atualizarAtor(ator);
            System.out.println("Ator atualizado com sucesso!");
        } else {
            System.out.println("Ator não encontrado.");
        }
    }

    private void listarAtores() {
        System.out.println("\n===== LISTAR ATORES =====");
        atorController.listarAtores().forEach(ator ->
                System.out.printf("Nome: %s | CPF: %s | Email: %s\n", ator.getNome(), ator.getCpf(), ator.getEmail())
        );
    }

    private void exibirMenuFilmeAtor() {
        int selecao;

        do {
            System.out.println("\n===== GERENCIAR ASSOCIAÇÃO FILME-ATOR =====");
            System.out.println("1 - Associar Ator a Filme");
            System.out.println("2 - Listar Associações");
            System.out.println("3 - Voltar ao Menu de Atores");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> associarAtorAFilme();
                case 2 -> listarAssociacoes();
                case 3 -> System.out.println("Voltando ao Menu de Atores...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 3);
    }

    private void associarAtorAFilme() {
        System.out.println("\n===== ASSOCIAÇÃO DE ATOR A FILME =====");

        System.out.print("ID do Ator: ");
        int idAtor = scanner.nextInt();
        scanner.nextLine();

        System.out.print("ID do Filme: ");
        int idFilme = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Personagem: ");
        String personagem = scanner.nextLine();

        System.out.print("É o principal? (true/false): ");
        boolean principal = scanner.nextBoolean();

        filmeAtorController.associarAtorFilme(idAtor, idFilme, personagem, principal);
    }

    private void listarAssociacoes() {
        System.out.println("\n===== LISTAR ASSOCIAÇÕES =====");
        filmeAtorController.listarFilmesAtores().forEach(fa ->
                System.out.printf("ID FilmeAtor: %d | Ator: %s | Filme: %s | Personagem: %s | Principal: %s\n",
                        fa.getIdFilmeAtor(),
                        fa.getAtor().getNome(),
                        fa.getFilme().getTitulo(),
                        fa.getPersonagem(),
                        fa.isPrincipal() ? "Sim" : "Não")
        );
    }
}

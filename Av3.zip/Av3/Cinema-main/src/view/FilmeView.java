package view;

import controller.FilmeController;
import model.Filme;
import model.Genero;

import java.util.List;
import java.util.Scanner;

public class FilmeView {

    private final Scanner scanner = new Scanner(System.in);
    private final FilmeController filmeController = new FilmeController();

    public void exibirMenuFilme() {
        int selecao;

        do {
            System.out.println("\n===== GERENCIAR FILMES =====");
            System.out.println("1 - Cadastrar Filme");
            System.out.println("2 - Editar Filme");
            System.out.println("3 - Listar Filmes");
            System.out.println("4 - Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> cadastrarFilme();
                case 2 -> editarFilme();
                case 3 -> listarFilmes();
                case 4 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 4);
    }

    private void cadastrarFilme() {
        System.out.println("\n===== CADASTRAR FILME =====");


        System.out.print("Título: ");
        String titulo = scanner.nextLine();

        System.out.print("Classificação: ");
        int classificacao = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Gênero (Descrição): ");
        String descricaoGenero = scanner.nextLine();

        System.out.print("Status (Ativo/Inativo): ");
        String status = scanner.nextLine();

        filmeController.cadastrarFilme(titulo, classificacao, descricaoGenero, status);

        System.out.println("Filme cadastrado com sucesso!");
    }


    private void editarFilme() {
        System.out.println("\n===== EDITAR FILME =====");

        System.out.print("Digite o ID ou Título do filme a ser editado: ");
        String idOuTitulo = scanner.nextLine();

        System.out.print("Novo Título: ");
        String novoTitulo = scanner.nextLine();

        System.out.print("Nova Classificação: ");
        int novaClassificacao = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Novo Gênero (Descrição): ");
        String novaDescricaoGenero = scanner.nextLine();

        System.out.print("Novo Status (Ativo/Inativo): ");
        String novoStatus = scanner.nextLine();


        Genero novoGenero = new Genero(0, novaDescricaoGenero, novoStatus);


        filmeController.editarFilme(idOuTitulo, novoTitulo, novaClassificacao, novoGenero, novoStatus);
    }

    private void listarFilmes() {
        System.out.println("\n===== LISTAR FILMES =====");
        List<Filme> filmes = filmeController.listarFilmes();

        if (filmes.isEmpty()) {
            System.out.println("Nenhum filme cadastrado.");
        } else {
            for (Filme filme : filmes) {
                System.out.printf("ID: %d | Título: %s | Classificação: %d | Gênero: %s | Status: %s\n",
                        filme.getIdFilme(),
                        filme.getTitulo(),
                        filme.getClassificacao(),
                        filme.getGenero().getDescricao(),
                        filme.getStatus());
            }
        }
    }
}

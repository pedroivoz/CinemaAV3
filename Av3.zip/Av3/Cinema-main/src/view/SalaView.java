package view;

import controller.SalaController;
import controller.TipoAssentoController;
import model.Sala;
import model.TipoAssento;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SalaView {
    private SalaController salaController = new SalaController();
    private TipoAssentoController tipoAssentoController = new TipoAssentoController();
    private Scanner scanner = new Scanner(System.in);

    public void exibirMenuSala() {
        int opcao;
        do {
            System.out.println("========== GERENCIAR SALAS ==========");
            System.out.println("1 - Cadastrar Sala");
            System.out.println("2 - Listar Salas");
            System.out.println("3 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarSala();
                case 2 -> listarSalas();
                case 3 -> System.out.println("Voltando ao menu anterior...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 3);
    }

    private void cadastrarSala() {

        System.out.print("Digite a descrição da sala: ");
        String descricao = scanner.nextLine();
        System.out.print("Digite a capacidade da sala: ");
        int capacidade = scanner.nextInt();
        scanner.nextLine();


        List<TipoAssento> tiposAssentos = tipoAssentoController.listarTipoAssento();
        if (tiposAssentos.isEmpty()) {
            System.out.println("Nenhum tipo de assento cadastrado. Cadastre antes de continuar.");
            return;
        }

        System.out.println("Escolha os tipos de assentos e quantos deseja adicionar:");
        List<TipoAssento> tiposSelecionados = new ArrayList<>();

        for (int i = 0; i < tiposAssentos.size(); i++) {
            System.out.println((i + 1) + " - " + tiposAssentos.get(i).getDescricao());
        }


        int escolha;
        do {
            System.out.print("Digite o número do tipo de assento (0 para terminar): ");
            escolha = scanner.nextInt();
            if (escolha > 0 && escolha <= tiposAssentos.size()) {
                TipoAssento tipoEscolhido = tiposAssentos.get(escolha - 1);
                System.out.print("Digite a quantidade de assentos desse tipo: ");
                int quantidade = scanner.nextInt();
                scanner.nextLine();
                tiposSelecionados.add(tipoEscolhido);
            }
        } while (escolha != 0);


        salaController.cadastrarSala(descricao, capacidade, tiposSelecionados);
        System.out.println("Sala cadastrada com sucesso!");
    }

    public void listarSalas() {
        List<Sala> salas = salaController.listarSalas();

        if (salas.isEmpty()) {
            System.out.println("Nenhuma sala cadastrada.");
        } else {
            System.out.println("========== SALAS CADASTRADAS ==========");
            for (Sala sala : salas) {
                System.out.println("ID: " + sala.getIdSala() +
                        ", Descrição: " + sala.getDescricao() +
                        ", Capacidade: " + sala.getCapacidadeSala() +
                        ", Status: " + sala.getStatus());
            }
        }
    }
}

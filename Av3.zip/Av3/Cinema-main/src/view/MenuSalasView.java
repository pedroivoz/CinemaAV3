package view;

import java.util.Scanner;

public class MenuSalasView {

    private final Scanner scanner = new Scanner(System.in);


    public void exibirMenuGerenciamentoSalas() {
        int selecao;

        do {
            System.out.println("========== GERENCIAR SALAS CINEMA UNIFOR==========");
            System.out.println("1 - Gerenciar Salas");
            System.out.println("2 - Gerenciar SalaAssentos");
            System.out.println("3 - Gerenciar Assentos");
            System.out.println("4 - Voltar");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> new SalaView().exibirMenuSala();
                case 2 -> new SalaAssentoView().exibirMenuSalaAssento();
                case 3 -> new TipoAssentoView().exibirMenuTipoAssento();
                case 4 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 4);
    }
}

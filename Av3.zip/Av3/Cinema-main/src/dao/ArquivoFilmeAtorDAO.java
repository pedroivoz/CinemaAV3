package dao;

import model.Ator;
import model.Filme;
import model.FilmeAtor;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArquivoFilmeAtorDAO {

    private static final String FILE_PATH = "data/filme_ator.txt";
    private static final String CAMINHO_FILME = "data/filme.txt";


    public int gerarNovoId() {
        int maiorId = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                int idAtual = Integer.parseInt(partes[0]);
                if (idAtual > maiorId) {
                    maiorId = idAtual;
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao gerar novo ID: " + e.getMessage());
        }
        return maiorId + 1;
    }


    public void salvarFilmeAtor(FilmeAtor filmeAtor) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            bw.write(String.format("%d;%s;%d;%s;%b%n",
                    filmeAtor.getIdFilmeAtor(),
                    filmeAtor.getAtor().getCpf(),
                    filmeAtor.getFilme().getIdFilme(),
                    filmeAtor.getPersonagem(),
                    filmeAtor.isPrincipal()));
        } catch (IOException e) {
            System.out.println("Erro ao salvar associação Filme-Ator: " + e.getMessage());
        }
    }


    public List<FilmeAtor> listarFilmesAtores() {
        List<FilmeAtor> lista = new ArrayList<>();
        ArquivoAtorDAO atorDAO = new ArquivoAtorDAO();
        ArquivoFilmeDAO filmeDAO = new ArquivoFilmeDAO();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                int idFilmeAtor = Integer.parseInt(partes[0]);
                String cpfAtor = partes[1];
                int idFilme = Integer.parseInt(partes[2]);
                String personagem = partes[3];
                boolean principal = Boolean.parseBoolean(partes[4]);

                Ator ator = atorDAO.buscarAtorPorCpf(cpfAtor);
                Filme filme = filmeDAO.buscarFilmePorId(idFilme);
                if (ator != null && filme != null) {
                    lista.add(new FilmeAtor(idFilmeAtor, ator, filme, personagem, principal));
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao listar associações Filme-Ator: " + e.getMessage());
        }
        return lista;
    }


    public FilmeAtor buscarFilmeAtorPorId(int idFilmeAtor) {
        ArquivoAtorDAO atorDAO = new ArquivoAtorDAO();
        ArquivoFilmeDAO filmeDAO = new ArquivoFilmeDAO();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(";");
                if (Integer.parseInt(partes[0]) == idFilmeAtor) {
                    String cpfAtor = partes[1];
                    int idFilme = Integer.parseInt(partes[2]);
                    String personagem = partes[3];
                    boolean principal = Boolean.parseBoolean(partes[4]);

                    Ator ator = atorDAO.buscarAtorPorCpf(cpfAtor);
                    Filme filme = filmeDAO.buscarFilmePorId(idFilme);
                    if (ator != null && filme != null) {
                        return new FilmeAtor(idFilmeAtor, ator, filme, personagem, principal);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao buscar associação Filme-Ator por ID: " + e.getMessage());
        }
        return null;
    }


    public void atualizarFilmeAtor(FilmeAtor filmeAtorAtualizado) {
        List<FilmeAtor> lista = listarFilmesAtores();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, false))) {
            for (FilmeAtor fa : lista) {
                if (fa.getIdFilmeAtor() == filmeAtorAtualizado.getIdFilmeAtor()) {
                    fa = filmeAtorAtualizado;
                }
                bw.write(String.format("%d;%s;%d;%s;%b%n",
                        fa.getIdFilmeAtor(),
                        fa.getAtor().getCpf(),
                        fa.getFilme().getIdFilme(),
                        fa.getPersonagem(),
                        fa.isPrincipal()));
            }
        } catch (IOException e) {
            System.out.println("Erro ao atualizar associação Filme-Ator: " + e.getMessage());
        }
    }
}

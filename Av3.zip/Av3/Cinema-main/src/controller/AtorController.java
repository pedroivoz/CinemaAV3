package controller;

import model.Ator;
import dao.ArquivoAtorDAO;

import java.util.List;

public class AtorController {

    ArquivoAtorDAO atorDAO = new ArquivoAtorDAO();

    public void cadastrarAtor(String cpf, String nome, String email, int registro) {
        Ator ator = new Ator(cpf, nome, email, registro);
        atorDAO.salvarAtor(ator);
    }

    public List<Ator> listarAtores() {
        return atorDAO.listarAtores();
    }

    public void editarAtor(String cpf, String nome, String email) {
        Ator ator = atorDAO.buscarAtorPorCpf(cpf);
        if (ator != null) {
            ator.setNome(nome);
            ator.setEmail(email);
            atorDAO.atualizarAtor(ator);
        }

    }
    public Ator buscarAtorPorCpf(String cpf) {
        return atorDAO.buscarAtorPorCpf(cpf);
    }
    public void atualizarAtor(Ator ator) {

        Ator atorExistente = atorDAO.buscarAtorPorCpf(ator.getCpf());
        if (atorExistente != null) {

            atorExistente.setNome(ator.getNome());
            atorExistente.setEmail(ator.getEmail());
            atorExistente.setRegistro(ator.getRegistro());


            atorDAO.atualizarAtor(atorExistente);
            System.out.println("Ator atualizado com sucesso!");
        } else {
            System.out.println("Ator não encontrado!");
        }
    }
}

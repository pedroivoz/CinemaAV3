package dao;

import model.Sessao;
import model.Filme;
import model.Sala;
import model.Funcionario;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SessaoDAO {
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", java.util.Locale.ENGLISH);

    private static final String CAMINHO_ARQUIVO = "data/sessoes.txt";
    private final List<Sessao> sessoes = new ArrayList<>();
    private int idCounter = 1;

    public Sessao buscarSessaoPorId(int idSessao) {
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Sessao sessao = converterLinhaParaSessao(linha);
                if (sessao != null && sessao.getIdSessao() == idSessao) {
                    return sessao;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao buscar sessão por ID no arquivo: " + e.getMessage());
        }
        return null;
    }

    public void cadastrarSessao(Sessao sessao) {
        sessao.setIdSessao(buscarMaiorIdSessao() + 1);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, true))) {
            String linha = formatarSessaoParaLinha(sessao);
            writer.write(linha);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erro ao salvar sessão: " + e.getMessage());
        }
    }

    public List<Sessao> listarSessoes() {
        List<Sessao> sessoes = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Sessao sessao = converterLinhaParaSessao(linha);
                if (sessao != null) {
                    sessoes.add(sessao);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler arquivo de sessões: " + e.getMessage());
        }
        return sessoes;
    }

    private String formatarSessaoParaLinha(Sessao sessao) {
        return sessao.getIdSessao() + ";" +
                dateFormat.format(sessao.getDataHoraSessao()) + ";" +
                sessao.getFilme().getIdFilme() + ";" +
                sessao.getSala().getIdSala() + ";" +
                sessao.getFuncionario().getMatricula() + ";" +
                sessao.getStatus();
    }

    private Sessao converterLinhaParaSessao(String linha) {
        try {
            String[] partes = linha.split(";");
            int idSessao = Integer.parseInt(partes[0]);


            Date dataHoraSessao = dateFormat.parse(partes[1]);

            Filme filme = new ArquivoFilmeDAO().buscarFilmePorId(Integer.parseInt(partes[2]));
            Sala sala = new SalaDAO().listarSalas().get(Integer.parseInt(partes[3]) - 1);
            Funcionario funcionario = new FuncionarioDAO().consultarFuncionarioPorMatricula(Integer.parseInt(partes[4]));
            String status = partes[5];

            return new Sessao(idSessao, dataHoraSessao, filme, sala, funcionario, status);
        } catch (Exception e) {
            System.err.println("Erro ao converter linha para sessão: " + e.getMessage());
            return null;
        }
    }
    public int buscarMaiorIdSessao() {
        int maiorId = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(";");
                int idAtual = Integer.parseInt(dados[0]);
                if (idAtual > maiorId) {
                    maiorId = idAtual;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao buscar maior ID de sessão: " + e.getMessage());
        }
        return maiorId;
    }

}

package view;

import controller.IngressoController;
import dao.SalaAssentoDAO;
import dao.SessaoDAO;
import model.Sessao;
import model.SalaAssento;
import java.util.Scanner;

public class IngressoView {

    private final Scanner scanner = new Scanner(System.in);
    private final IngressoController ingressoController = new IngressoController();

    public void exibirMenuIngresso() {
        int selecao;
        do {
            System.out.println("========== GERENCIAR INGRESSOS ==========");
            System.out.println("1 - Cadastrar Ingresso");
            System.out.println("2 - Listar Ingressos");
            System.out.println("3 - Voltar");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> cadastrarIngresso();
                case 2 -> listarIngressos();
                case 3 -> System.out.println("Voltando...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 3);
    }

    private void cadastrarIngresso() {
        System.out.print("Digite o valor do ingresso: ");
        double valorPago = scanner.nextDouble();
        scanner.nextLine();

        System.out.print("Digite o ID da sessão: ");
        int idSessao = scanner.nextInt();
        scanner.nextLine();
        Sessao sessao = new SessaoDAO().buscarSessaoPorId(idSessao);

        System.out.print("Digite o ID do assento: ");
        int idSalaAssento = scanner.nextInt();
        scanner.nextLine();
        SalaAssento salaAssento = new SalaAssentoDAO().buscarSalaAssentoPorId(idSalaAssento);

        ingressoController.cadastrarIngresso(valorPago, sessao, salaAssento);
    }

    private void listarIngressos() {
        System.out.println("===== LISTA DE INGRESSOS =====");
        ingressoController.listarIngressos().forEach(ingresso -> {
            System.out.println("ID: " + ingresso.getIdIngresso() +
                    ", Valor: " + ingresso.getValorPago() +
                    ", Sessão ID: " + ingresso.getSessao().getIdSessao() +
                    ", Assento ID: " + ingresso.getSalaAssento().getIdSalaAssento());
        });
    }
}

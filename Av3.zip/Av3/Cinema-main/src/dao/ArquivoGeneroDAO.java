package dao;

import model.Genero;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArquivoGeneroDAO {
    private static final String CAMINHO_ARQUIVO_GENERO = "data/generos.txt";


    public void salvarGenero(Genero genero) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO_GENERO, true))) {
            writer.write(String.format("%d;%s;%s\n",
                    genero.getId(),
                    genero.getDescricao(),
                    genero.getStatus()));
        } catch (IOException e) {
            System.err.println("Erro ao salvar gênero: " + e.getMessage());
        }
    }


    public List<Genero> listarGeneros() {
        List<Genero> generos = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO_GENERO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Genero genero = converterLinhaParaGenero(linha);
                if (genero != null) {
                    generos.add(genero);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao listar gêneros: " + e.getMessage());
        }

        return generos;
    }


    private Genero converterLinhaParaGenero(String linha) {
        String[] campos = linha.split(";");
        if (campos.length == 3) {
            int id = Integer.parseInt(campos[0]);
            String descricao = campos[1];
            String status = campos[2];
            return new Genero(id, descricao, status);
        }
        return null;
    }
    public int gerarNovoIdGenero() {
        int maiorId = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(CAMINHO_ARQUIVO_GENERO))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                int idAtual = Integer.parseInt(dados[0]);
                if (idAtual > maiorId) {
                    maiorId = idAtual;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao gerar novo ID para gênero: " + e.getMessage());
        }
        return maiorId + 1;
    }
    public Genero buscarGeneroPorDescricao(String descricao) {
        try (BufferedReader br = new BufferedReader(new FileReader(CAMINHO_ARQUIVO_GENERO))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                if (dados[1].equalsIgnoreCase(descricao)) {
                    int id = Integer.parseInt(dados[0]);
                    String status = dados[2];
                    return new Genero(id, descricao, status);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao buscar gênero: " + e.getMessage());
        }
        return null;
    }
}

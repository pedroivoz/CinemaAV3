package controller;

import dao.FuncionarioDAO;
import model.Funcionario;

import java.util.List;

public class FuncionarioController {
    private final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();


    public void cadastrarFuncionario(Funcionario funcionario) {
        funcionarioDAO.salvarFuncionario(funcionario);
    }


    public List<Funcionario> listarFuncionarios() {
        return funcionarioDAO.listarFuncionarios();
    }


    public Funcionario consultarFuncionarioPorMatricula(int matricula) {
        return funcionarioDAO.consultarFuncionarioPorMatricula(matricula);
    }
}

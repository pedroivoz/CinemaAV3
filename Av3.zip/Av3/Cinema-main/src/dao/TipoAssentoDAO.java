package dao;

import model.TipoAssento;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TipoAssentoDAO {

    private static final String CAMINHO_ARQUIVO = "data/tipo_assentos.txt";
    private final List<TipoAssento> tipoAssentos = new ArrayList<>();


    public void cadastrarTipoAssento(TipoAssento tipoAssento) {

        tipoAssento.setIdTipoAssento(obterProximoId());

        tipoAssentos.add(tipoAssento);
        salvarTipoAssentosNoArquivo();
    }


    private void salvarTipoAssentosNoArquivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, true))) {
            for (TipoAssento tipoAssento : tipoAssentos) {
                String linha = tipoAssento.getIdTipoAssento() + ";" + tipoAssento.getDescricao() + ";" + tipoAssento.getStatus();
                writer.write(linha);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar tipo de assentos no arquivo: " + e.getMessage());
        }
    }


    public TipoAssento buscarTipoAssentoPorDescricao(String descricao) {
        for (TipoAssento tipoAssento : tipoAssentos) {
            if (tipoAssento.getDescricao().equalsIgnoreCase(descricao)) {
                return tipoAssento;
            }
        }
        return null;
    }


    public List<TipoAssento> listarTipoAssentos() {

        carregarTipoAssentosDoArquivo();
        return tipoAssentos;
    }


    private void carregarTipoAssentosDoArquivo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(";");
                int idTipoAssento = Integer.parseInt(dados[0]);
                String descricao = dados[1];
                String status = dados[2];

                TipoAssento tipoAssento = new TipoAssento(idTipoAssento, descricao, status);
                tipoAssentos.add(tipoAssento);
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo de tipo de assentos: " + e.getMessage());
        }
    }
    public TipoAssento buscarTipoAssentoPorId(int idTipoAssento) {
        for (TipoAssento tipoAssento : tipoAssentos) {
            if (tipoAssento.getIdTipoAssento() == idTipoAssento) {
                return tipoAssento;
            }
        }
        return null;
    }


    private int obterProximoId() {
        int maxId = 0;
        for (TipoAssento tipoAssento : tipoAssentos) {
            if (tipoAssento.getIdTipoAssento() > maxId) {
                maxId = tipoAssento.getIdTipoAssento();
            }
        }
        return maxId + 1;
    }
}

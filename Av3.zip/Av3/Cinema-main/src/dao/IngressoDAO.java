package dao;

import exceptions.ArquivoNaoEncontradoException;
import model.Ingresso;
import model.SalaAssento;
import model.Sessao;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class IngressoDAO {

    private static final String CAMINHO_ARQUIVO = "data/ingressos.txt";


    public void cadastrarIngresso(Ingresso ingresso) throws ArquivoNaoEncontradoException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO, true))) {
            if (writer==null)
                throw new ArquivoNaoEncontradoException();
            String linha = formatarIngressoParaLinha(ingresso);
            writer.write(linha);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erro ao salvar ingresso: " + e.getMessage());
        }
    }


    public List<Ingresso> listarIngressos() {
        List<Ingresso> ingressos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                Ingresso ingresso = converterLinhaParaIngresso(linha);
                if (ingresso != null) {
                    ingressos.add(ingresso);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler arquivo de ingressos: " + e.getMessage());
        }
        return ingressos;
    }

    private String formatarIngressoParaLinha(Ingresso ingresso) {
        return ingresso.getIdIngresso() + ";" +
                ingresso.getValorPago() + ";" +
                ingresso.getSessao().getIdSessao() + ";" +
                ingresso.getSalaAssento().getIdSalaAssento();
    }

    private Ingresso converterLinhaParaIngresso(String linha) {
        try {
            String[] partes = linha.split(";");
            int idIngresso = Integer.parseInt(partes[0]);
            double valorPago = Double.parseDouble(partes[1]);
            Sessao sessao = new SessaoDAO().buscarSessaoPorId(Integer.parseInt(partes[2]));
            SalaAssento salaAssento = new SalaAssentoDAO().buscarSalaAssentoPorId(Integer.parseInt(partes[3]));
            return new Ingresso(idIngresso, valorPago, sessao, salaAssento);
        } catch (Exception e) {
            System.err.println("Erro ao converter linha para ingresso: " + e.getMessage());
            return null;
        }
    }
}

package view;

import controller.FuncionarioController;
import model.Funcionario;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class FuncionarioView {
    private FuncionarioController funcionarioController = new FuncionarioController();
    private Scanner scanner = new Scanner(System.in);

    public void exibirMenuFuncionario() {
        int opcao;
        do {
            System.out.println("========== GERENCIAR FUNCIONÁRIOS ==========");
            System.out.println("1 - Cadastrar Funcionário");
            System.out.println("2 - Listar Funcionários");
            System.out.println("3 - Consultar Funcionário por Matrícula");
            System.out.println("4 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarFuncionario();
                case 2 -> listarFuncionarios();
                case 3 -> consultarFuncionario();
                case 4 -> System.out.println("Voltando ao menu anterior...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 4);
    }

    private void cadastrarFuncionario() {
        System.out.print("Digite o CPF do funcionário: ");
        String cpf = scanner.nextLine();
        System.out.print("Digite o nome do funcionário: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o email do funcionário: ");
        String email = scanner.nextLine();
        System.out.print("Digite a matrícula do funcionário: ");
        int matricula = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Digite a data  de inicio do vinculo de trabalho (yyyy-MM-dd): ");
        String horarioTrabalhoStr = scanner.nextLine();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date horarioTrabalho = null;
        try {
            horarioTrabalho = sdf.parse(horarioTrabalhoStr);
        } catch (Exception e) {
            System.out.println("Formato de data inválido.");
            return;
        }

        Funcionario funcionario = new Funcionario(cpf, nome, email, matricula, horarioTrabalho);
        funcionarioController.cadastrarFuncionario(funcionario);
        System.out.println("Funcionário cadastrado com sucesso!");
    }

    private void listarFuncionarios() {
        List<Funcionario> funcionarios = funcionarioController.listarFuncionarios();

        if (funcionarios.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
        } else {
            System.out.println("========== FUNCIONÁRIOS CADASTRADOS ==========");
            for (Funcionario funcionario : funcionarios) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                System.out.println("Matrícula: " + funcionario.getMatricula() +
                        ", Nome: " + funcionario.getNome() +
                        ", CPF: " + funcionario.getCpf() +
                        ", Email: " + funcionario.getEmail() +
                        ", Horário de Trabalho: " + sdf.format(funcionario.getHorarioTrabalho()));
            }
        }
    }

    private void consultarFuncionario() {
        System.out.print("Digite a matrícula do funcionário que deseja consultar: ");
        int matricula = scanner.nextInt();
        Funcionario funcionario = funcionarioController.consultarFuncionarioPorMatricula(matricula);

        if (funcionario != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Matrícula: " + funcionario.getMatricula() +
                    ", Nome: " + funcionario.getNome() +
                    ", CPF: " + funcionario.getCpf() +
                    ", Email: " + funcionario.getEmail() +
                    ", Horário de Trabalho: " + sdf.format(funcionario.getHorarioTrabalho()));
        } else {
            System.out.println("Funcionário não encontrado.");
        }
    }
}

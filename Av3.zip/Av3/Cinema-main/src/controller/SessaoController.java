package controller;

import dao.SessaoDAO;
import model.Sessao;

import java.util.List;

public class SessaoController {

    private final SessaoDAO sessaoDAO = new SessaoDAO();


    public void cadastrarSessao(Sessao sessao) {
        sessaoDAO.cadastrarSessao(sessao);
    }


    public List<Sessao> listarSessoes() {
        return sessaoDAO.listarSessoes();
    }
}

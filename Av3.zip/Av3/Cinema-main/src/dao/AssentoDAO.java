package dao;

import model.Assento;
import model.TipoAssento;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AssentoDAO {

    private static final String CAMINHO_ARQUIVO = "data/assentos.txt";
    private final List<Assento> assentos = new ArrayList<>();
    private final TipoAssentoDAO tipoAssentoDAO = new TipoAssentoDAO();

    public void cadastrarAssento(Assento assento) {
        assento.setNumero(obterProximoId());
        assentos.add(assento);
        salvarAssentosNoArquivo();
    }

    private void salvarAssentosNoArquivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CAMINHO_ARQUIVO))) {
            for (Assento assento : assentos) {
                String linha = assento.getNumero() + ";" + assento.getTipoAssento().getDescricao();
                writer.write(linha);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar assentos no arquivo: " + e.getMessage());
        }
    }

    public List<Assento> listarAssentos() {
        carregarAssentosDoArquivo();
        return new ArrayList<>(assentos);
    }

    private void carregarAssentosDoArquivo() {
        assentos.clear();


        List<TipoAssento> tiposAssento = tipoAssentoDAO.listarTipoAssentos();
        if (tiposAssento.isEmpty()) {
            System.err.println("Nenhum tipo de assento disponível para carregar os assentos.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(CAMINHO_ARQUIVO))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] dados = linha.split(";");
                if (dados.length != 2) {
                    System.err.println("Linha inválida no arquivo de assentos: " + linha);
                    continue;
                }

                int idAssento = Integer.parseInt(dados[0]);
                String descricaoTipoAssento = dados[1];


                TipoAssento tipoAssento = tipoAssentoDAO.buscarTipoAssentoPorDescricao(descricaoTipoAssento);
                if (tipoAssento != null) {
                    Assento assento = new Assento(idAssento, tipoAssento);
                    assentos.add(assento);
                } else {
                    System.err.println("Tipo de assento não encontrado: " + descricaoTipoAssento);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo de assentos: " + e.getMessage());
        }
    }

    private int obterProximoId() {
        int maxId = 0;
        for (Assento assento : assentos) {
            if (assento.getNumero() > maxId) {
                maxId = assento.getNumero();
            }
        }
        return maxId + 1;
    }

    public Assento buscarAssentoPorId(int idAssento) {
        for (Assento assento : assentos) {
            if (assento.getNumero() == idAssento) {
                return assento;
            }
        }
        return null;
    }
}

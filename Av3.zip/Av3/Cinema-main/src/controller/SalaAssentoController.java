package controller;

import dao.SalaAssentoDAO;
import model.Assento;
import model.Sala;

import java.util.List;

public class SalaAssentoController {
    private SalaAssentoDAO salaAssentoDAO = new SalaAssentoDAO();

    public void salvarSalaComAssentos(Sala sala) {
        salaAssentoDAO.cadastrarSalaComAssentos(sala);
    }

    public List<Assento> listarAssentosPorSala(int idSala) {
        return salaAssentoDAO.listarAssentosPorSala(idSala);
    }
}

package controller;

import dao.ArquivoAtorDAO;
import dao.ArquivoFilmeAtorDAO;
import dao.ArquivoFilmeDAO;
import model.FilmeAtor;
import model.Ator;
import model.Filme;
import java.util.List;

public class FilmeAtorController {

    private final ArquivoFilmeAtorDAO filmeAtorDAO = new ArquivoFilmeAtorDAO();
    private final ArquivoFilmeDAO filmeDAO = new ArquivoFilmeDAO();
    private final ArquivoAtorDAO atorDAO = new ArquivoAtorDAO();
    ArquivoFilmeAtorDAO ArquivoFilmeAtorDAO = new ArquivoFilmeAtorDAO();


    public void associarAtorFilme(int idAtor, int idFilme, String personagem, boolean principal) {
        ArquivoFilmeAtorDAO arquivoFilmeAtorDAO = new ArquivoFilmeAtorDAO();


        Ator ator = atorDAO.buscarAtorPorId(idAtor);
        Filme filme = filmeDAO.buscarFilmePorId(idFilme);

        if (ator != null && filme != null) {
            int novoId = arquivoFilmeAtorDAO.gerarNovoId();
            FilmeAtor filmeAtor = new FilmeAtor(novoId, ator, filme, personagem, principal);
            arquivoFilmeAtorDAO.salvarFilmeAtor(filmeAtor);
            System.out.println("Associação ator-filme criada com sucesso!");
        } else {
            System.out.println("Ator ou Filme não encontrado.");
        }
    }


    public List<FilmeAtor> listarFilmesAtores() {
        return ArquivoFilmeAtorDAO.listarFilmesAtores();
    }


    public void editarAssociacao(int idFilmeAtor, String personagem, boolean principal) {
        FilmeAtor filmeAtor = ArquivoFilmeAtorDAO.buscarFilmeAtorPorId(idFilmeAtor);
        if (filmeAtor != null) {
            filmeAtor.setPersonagem(personagem);
            filmeAtor.setPrincipal(principal);
            ArquivoFilmeAtorDAO.atualizarFilmeAtor(filmeAtor);
            System.out.println("Associação editada com sucesso!");
        } else {
            System.out.println("Associação não encontrada.");
        }
    }
}

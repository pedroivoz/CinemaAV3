package controller;

import model.TipoAssento;
import dao.TipoAssentoDAO;

import java.util.List;

public class TipoAssentoController {

   TipoAssentoDAO dao = new TipoAssentoDAO();
   TipoAssentoDAO tipoAssentoDAO = new TipoAssentoDAO();


    public TipoAssento buscarOuCadastrarTipoAssento(String descricao, String status) {
        TipoAssento tipoAssento = tipoAssentoDAO.buscarTipoAssentoPorDescricao(descricao);

        if (tipoAssento == null) {
            tipoAssento = new TipoAssento(0, descricao, status);
            tipoAssentoDAO.cadastrarTipoAssento(tipoAssento);
        }

        return tipoAssento;
    }



    public void cadastrarTipoAssento(TipoAssento tipoAssento) {
        dao.cadastrarTipoAssento(tipoAssento);
    }


    public List<TipoAssento> listarTipoAssento() {
        return dao.listarTipoAssentos();
    }
    public TipoAssento buscarTipoAssentoPorDescricao(String descricao) {
        return tipoAssentoDAO.listarTipoAssentos().stream()
                .filter(tipo -> tipo.getDescricao().equalsIgnoreCase(descricao))
                .findFirst()
                .orElse(null);
    }


}

package model;

import java.util.List;

public class Sala {
    private int idSala;
    private int capacidadeSala;
    private String descricao;
    private String status;
    private List<Assento> assentos;

    public Sala(int idSala, int capacidadeSala, String descricao, String status) {
        this.idSala = idSala;
        this.capacidadeSala = capacidadeSala;
        this.descricao = descricao;
        this.status = status;
    }
    public Sala(int idSala, String descricao, int capacidadeSala) {
        this.idSala = idSala;
        this.descricao = descricao;
        this.capacidadeSala = capacidadeSala;
    }
    public Sala(int idSala, String descricao, int capacidadeSala, List<Assento> assentos) {
        this.idSala = idSala;
        this.descricao = descricao;
        this.capacidadeSala = capacidadeSala;
        this.assentos = assentos;
        this.status = "Ativo";
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getCapacidadeSala() {
        return capacidadeSala;
    }

    public void setCapacidadeSala(int capacidadeSala) {
        this.capacidadeSala = capacidadeSala;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {

        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {

        this.status = status;
    }
    public List<Assento> getAssentos() {

        return assentos;
    }

    public void setAssentos(List<Assento> assentos) {

        this.assentos = assentos;
    }


}

package view;

import controller.AssentoController;
import controller.TipoAssentoController;
import model.Assento;
import model.TipoAssento;

import java.util.List;
import java.util.Scanner;

public class AssentoView {

    private final Scanner scanner = new Scanner(System.in);
    private final AssentoController assentoController = new AssentoController();
    private final TipoAssentoController tipoAssentoController = new TipoAssentoController();


    public void exibirMenuAssento() {
        int opcao;
        do {
            System.out.println("========== GERENCIAR ASSENTOS ==========");
            System.out.println("1 - Cadastrar Assento");
            System.out.println("2 - Listar Assentos");
            System.out.println("3 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> cadastrarAssento();
                case 2 -> listarAssentos();
                case 3 -> System.out.println("Voltando ao menu anterior...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 3);
    }


    private void cadastrarAssento() {
        System.out.print("Digite a descrição do Tipo de Assento: ");
        String descricao = scanner.nextLine();

        System.out.print("Digite o status do Tipo de Assento (Ativo/Inativo): ");
        String status = scanner.nextLine();


        TipoAssento tipoAssento = tipoAssentoController.buscarTipoAssentoPorDescricao(descricao);
        if (tipoAssento == null) {

            tipoAssento = new TipoAssento(0,descricao, status);
            tipoAssentoController.cadastrarTipoAssento(tipoAssento);
            System.out.println("Novo tipo de assento cadastrado.");
        } else {
            System.out.println("Tipo de assento existente selecionado.");
        }


        Assento assento = new Assento(0, tipoAssento);
        assentoController.cadastrarAssento(assento);
        System.out.println("Assento cadastrado com sucesso.");
    }


    private void listarAssentos() {
        List<Assento> assentos = assentoController.listarAssentos();

        if (assentos.isEmpty()) {
            System.out.println("Nenhum assento cadastrado.");
        } else {
            System.out.println("========== ASSENTOS ==========");
            for (Assento assento : assentos) {
                System.out.println("ID: " + assento.getNumero() +
                        ", Tipo de Assento: " + assento.getTipoAssento());
            }
        }
    }
}

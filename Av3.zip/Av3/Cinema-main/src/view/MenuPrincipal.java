package view;

import java.util.Scanner;

public class MenuPrincipal {

    private final Scanner scanner = new Scanner(System.in);

    public void exibirMenuPrincipal() {
        int selecao;

        do {
            System.out.println("========== CINEMA UNIFOR ==========");
            System.out.println("1 - Gerenciar Filmes | 2 - Gerenciar Sessões | 3 - Gerenciar Salas | 4 - Gerenciar Ingressos | 5 - Gerenciar Funcionários |");
            System.out.println("6 - Gerenciar Atores e Associação Filme-Ator | 7 - Sair ");
            System.out.print("Escolha uma opção: ");
            selecao = scanner.nextInt();
            scanner.nextLine();

            switch (selecao) {
                case 1 -> new FilmeView().exibirMenuFilme();
                case 2 -> new SessaoView().exibirMenuSessao();
                case 3 -> new MenuSalasView().exibirMenuGerenciamentoSalas();
                case 4 -> new IngressoView().exibirMenuIngresso();
                case 5 -> new FuncionarioView().exibirMenuFuncionario();
                case 6 -> new MenuAtores().exibirMenuAtores();
                case 7 -> System.out.println("Sainddo...");
                default -> System.out.println("Opção inválida. Tente novamente.");
            }
        } while (selecao != 7);
    }
}

package controller;

import dao.ArquivoFilmeDAO;
import dao.ArquivoGeneroDAO;
import model.Filme;
import model.Genero;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class FilmeController {


    ArquivoFilmeDAO arquivoFilmeDAO = new ArquivoFilmeDAO();
    ArquivoGeneroDAO arquivoGeneroDAO = new ArquivoGeneroDAO();

    private final List<Filme> filmes = new ArrayList<>();


    public void cadastrarFilme(String titulo, int classificacao, String descricaoGenero, String statusFilme) {

        int maiorIdAtual = arquivoFilmeDAO.buscarMaiorIdFilme();
        int novoIdFilme = maiorIdAtual + 1;


        Genero generoExistente = arquivoGeneroDAO.buscarGeneroPorDescricao(descricaoGenero);

        Genero generoUtilizado;
        if (generoExistente != null) {
            generoUtilizado = generoExistente;
        } else {

            int novoIdGenero = arquivoGeneroDAO.gerarNovoIdGenero();
            generoUtilizado = new Genero(novoIdGenero, descricaoGenero, statusFilme);
            arquivoGeneroDAO.salvarGenero(generoUtilizado);
        }


        Filme novoFilme = new Filme(novoIdFilme, classificacao, titulo, generoUtilizado, statusFilme);
        filmes.add(novoFilme);


        arquivoFilmeDAO.cadastrarFilme(novoFilme);

        System.out.println("Filme cadastrado com sucesso!");
    }


    public void editarFilme(String idOuTitulo, String novoTitulo, int novaClassificacao, Genero novoGenero, String novoStatus) {
        Filme filmeEncontrado = buscarFilme(idOuTitulo);

        if (filmeEncontrado != null) {

            filmeEncontrado.setTitulo(novoTitulo);
            filmeEncontrado.setClassificacao(novaClassificacao);
            filmeEncontrado.setGenero(novoGenero);
            filmeEncontrado.setStatus(novoStatus);


            arquivoFilmeDAO.editarFilme(filmeEncontrado);

            System.out.println("Filme atualizado com sucesso!");
        } else {
            System.out.println("Filme não encontrado.");
        }
    }
    public Filme buscarFilmePorId(int idFilme) {
        filmes.clear();
        filmes.addAll(arquivoFilmeDAO.listarFilmes());

        return filmes.stream()
                .filter(filme -> filme.getIdFilme() == idFilme)
                .findFirst()
                .orElse(null);
    }


    public List<Filme> listarFilmes() {
        filmes.clear();
        filmes.addAll(arquivoFilmeDAO.listarFilmes());
        return filmes;
    }


    private Filme buscarFilme(String idOuTitulo) {
        try {

            int id = Integer.parseInt(idOuTitulo);
            return filmes.stream()
                    .filter(filme -> filme.getIdFilme() == id)
                    .findFirst()
                    .orElse(null);
        } catch (NumberFormatException e) {

            return filmes.stream()
                    .filter(filme -> filme.getTitulo().equalsIgnoreCase(idOuTitulo))
                    .findFirst()
                    .orElse(null);
        }
    }
}
